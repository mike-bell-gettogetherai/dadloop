"""Author: Swami Chandrasekaran
Last Modified: 2026-08-29
Purpose: CLI entry point for launching the TUI or REPL.

Entry point.

    python -m dadloop            launch the TUI (falls back to REPL if needed)
    python -m dadloop --repl     force the plain terminal REPL
    python -m dadloop --improve  run the recursive self-improvement loop
    python -m dadloop --console  serve Mom's Console in a browser
    dadloop                      console script (after `pip install -e .`)
"""
import sys

from dadloop import AgentLoop


def main() -> None:
    dad = AgentLoop()

    if "--console" in sys.argv:
        # Mom's Console reads the journal and never touches the harness, so it
        # runs on its own rather than alongside a turn.
        try:
            from console.server import main as run_console
        except ImportError:
            raise SystemExit("Mom's Console needs fastapi and uvicorn:\n"
                             "    pip install fastapi uvicorn")
        raise SystemExit(run_console())

    if "--improve" in sys.argv:
        from dadloop.improve_cli import run_improve
        raise SystemExit(run_improve(dad))

    if "--repl" in sys.argv:
        dad.run()
        return

    try:
        from dadloop.tui import launch
    except ImportError:
        print("(Textual not installed — falling back to REPL. "
              "`pip install textual` for the full TUI.)\n")
        dad.run()
        return

    launch(dad)


if __name__ == "__main__":
    main()
